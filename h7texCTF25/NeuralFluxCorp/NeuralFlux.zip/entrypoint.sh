#!/bin/sh



# Generate FLAG at runtime using uuidgen and write to /.dockerenv
FLAG="FLAG=H7CTF{FR0m_m1sc0nfigs_4ND_API_ATT4CK5_T0_XX3_1nj3ctioN_$(uuidgen)}"
echo "$FLAG" > /.dockerenv
chmod 644 /.dockerenv

# Execute the main command (start.sh)
exec "$@"
