# GitHub Copilot Instructions

## Project Context

This project is for Neural Flux, an AI company.
Everything u do here should very much imply AN company vibes.
Images u can get from unsplash or pexels. or any such free image site.

## Development Guidelines

### Technology Stack

- Use only static HTML, CSS, and JavaScript
- Use Tailwind CSS for styling
- No frameworks or build tools required

### Code Style

- No comments in code
- No explanations unless explicitly requested
- Write files directly without describing changes
- The files should be organized dont write everything in same file

### Design Requirements

- Every design must include both dark mode and light mode
- Include animations and visual effects to make designs look cool and modern
- Ensure smooth transitions and engaging user interactions

### Branding

- Company name: Neural Flux

### Output Format

- Provide complete, working code files
- Focus on implementation over documentation
- After everything is done all u have to tell me is what u changed in point wise summary
