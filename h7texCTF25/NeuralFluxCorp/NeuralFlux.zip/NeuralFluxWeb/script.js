const themeToggle = document.getElementById("themeToggle");
const sunIcon = document.getElementById("sunIcon");
const moonIcon = document.getElementById("moonIcon");
const html = document.documentElement;
const notifyForm = document.getElementById("notifyForm");
const formMessage = document.getElementById("formMessage");
const terminalOutput = document.getElementById("terminalOutput");

const terminalMessages = [
  { time: "00:00:05", status: "OK", text: "Compiling AI algorithms..." },
  { time: "00:00:06", status: "OK", text: "Optimizing data pipelines..." },
  { time: "00:00:07", status: "WAIT", text: "Running security protocols..." },
  { time: "00:00:08", status: "OK", text: "Connecting to neural grid..." },
  { time: "00:00:09", status: "OK", text: "System check complete." },
];

let messageIndex = 0;

function initTheme() {
  const savedTheme = localStorage.getItem("theme");
  if (savedTheme === "light") {
    html.classList.add("light");
    sunIcon.classList.remove("hidden");
    moonIcon.classList.add("hidden");
  } else {
    html.classList.remove("light");
    sunIcon.classList.add("hidden");
    moonIcon.classList.remove("hidden");
  }
}

themeToggle.addEventListener("click", () => {
  html.classList.toggle("light");

  if (html.classList.contains("light")) {
    localStorage.setItem("theme", "light");
    sunIcon.classList.remove("hidden");
    moonIcon.classList.add("hidden");
  } else {
    localStorage.setItem("theme", "dark");
    sunIcon.classList.add("hidden");
    moonIcon.classList.remove("hidden");
  }
});

function addTerminalMessage() {
  if (messageIndex < terminalMessages.length) {
    const msg = terminalMessages[messageIndex];
    const statusClass = msg.status === "OK" ? "success" : "warning";
    const p = document.createElement("p");
    p.innerHTML = `[<span class="time-stamp">${msg.time}</span>] <span class="${statusClass}">${msg.status}</span> ${msg.text}`;
    terminalOutput.appendChild(p);
    messageIndex++;
  } else {
    clearInterval(terminalInterval);
  }
}

const terminalInterval = setInterval(addTerminalMessage, 2000);

notifyForm.addEventListener("submit", (e) => {
  e.preventDefault();

  const emailInput = e.target.querySelector('input[type="email"]');
  const email = emailInput.value;

  formMessage.textContent =
    "Access request received. We will contact you soon.";
  formMessage.style.color = "var(--accent)";
  formMessage.classList.add("show");

  emailInput.value = "";

  setTimeout(() => {
    formMessage.classList.remove("show");
  }, 5000);
});

initTheme();
