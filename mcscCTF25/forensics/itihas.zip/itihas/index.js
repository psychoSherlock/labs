// psychoSherlock Website - No JS yet!
// Maybe I'll learn JavaScript soon :)
// Show a welcome alert for fun
window.onload = function () {
  // Dark mode toggle logic
  var btn = document.getElementById("darkModeToggle");
  var body = document.body;
  btn.textContent = body.classList.contains("dark-mode")
    ? "☀️ Light Mode"
    : "🌙 Dark Mode";
  btn.onclick = function () {
    body.classList.toggle("dark-mode");
    btn.textContent = body.classList.contains("dark-mode")
      ? "☀️ Light Mode"
      : "🌙 Dark Mode";
  };
};
